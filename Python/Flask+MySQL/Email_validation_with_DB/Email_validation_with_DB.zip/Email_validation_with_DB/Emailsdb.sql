INSERT INTO `emailsdb`.`Users` (`id`, `First_name`, `Last_name`, `email`, `created_at`, `updated_at`) VALUES ('1', 'Curtis', 'Nard', 'Curtisnard@gmail.com', now(), now());
select * from Users;